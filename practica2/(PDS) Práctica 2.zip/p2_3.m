% Programa P3_3
% Ilustraci�n de la propiedad de desplazamiento circular en el tiempo.

x = (1:8)';
N = length(x);			% Longitud de la secuencia.
n = 0:N-1;				% �ndices temporales.
m = 2;					% Desplazamiento temporal.

X = fft(x);                 % C�lculo de la DFT.
WN = exp(-1i*2*pi/N);   
fWN = WN.^((0:N-1)*m).';    % Se�al exponencial.
X_desp = fWN.*X;			% Multiplicamos la DFT por la exponencial..
x_desp = ifft(X_desp);      % Se�al desplazada circularmente en el tiempo.
x_desp = real(x_desp);     	% Se elimina la componente imaginaria residual.	

hfig = figure(3);
set(hfig,'Units', 'Normalized', 'OuterPosition', [0 0.05 0.95 0.95]);

subplot(2,1,1);
stem(n,x);grid
title('Secuencia original');
xlabel('Tiempo (n)')
ylabel('Amplitud')
subplot(2,1,2);
stem(n,x_desp);grid
xlabel('Tiempo (n)')
ylabel('Amplitud')
title('Secuencia desplazada circularmente');
